import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ClaimPool } from './components/ClaimPool';
import { ActivityPulse } from './components/ActivityPulse';
import { LiveLedger } from './components/LiveLedger';
import { Leaderboard } from './components/Leaderboard';
import { ToastContainer } from './components/ToastContainer';
import { LedgerItem, LeaderboardUser, ToastItem, RobloxUser } from './types';
import {
  INITIAL_WORLD_ZERO_MEMBERS,
  DEFAULT_AVATAR,
  fetchWorldZeroGroupMembersBackground,
} from './utils/roblox';
import { isSoundEnabled } from './utils/audio';

const INITIAL_LEDGER: LedgerItem[] = [
  {
    id: 'claim-100',
    sender: 'Daily Reward Pool',
    recipient: 'dev_controlx',
    amount: 5000,
    note: 'Tier 4 Community Reward Claim',
    status: 'CLAIMED',
    isWZ: true,
    time: 'Just now',
    avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-8D293B9D06B0E7DDA7B9C5AA65320608-Png/150/150/AvatarHeadshot/Png/noFilter',
    rolimonsUrl: 'https://www.rolimons.com/player/1191863800',
  },
  {
    id: 'claim-101',
    sender: 'Daily Reward Pool',
    recipient: 'queenchescax',
    amount: 5000,
    note: 'Daily Community Claim Reward',
    status: 'CLAIMED',
    isWZ: true,
    time: '2m ago',
    avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-19783A5D9D027A308A0F1DB7C6457C68-Png/150/150/AvatarHeadshot/Png/noFilter',
    rolimonsUrl: 'https://www.rolimons.com/player/8752624670',
  },
  {
    id: 'claim-102',
    sender: 'Daily Reward Pool',
    recipient: 'noochi1279',
    amount: 2500,
    note: 'Daily Community Claim Reward',
    status: 'CLAIMED',
    isWZ: true,
    time: '5m ago',
    avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-FC5C958FFBFCFD47C2E6E912C40B51DF-Png/150/150/AvatarHeadshot/Png/noFilter',
    rolimonsUrl: 'https://www.rolimons.com/player/499329340',
  },
  {
    id: 'claim-103',
    sender: 'Daily Reward Pool',
    recipient: 'Builderman',
    amount: 2500,
    note: 'Daily Tier 3 Claim',
    status: 'CLAIMED',
    isWZ: true,
    time: '11m ago',
    avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-156-PNG/150/150/AvatarHeadshot/Png/noFilter',
  },
  {
    id: 'claim-104',
    sender: 'Daily Reward Pool',
    recipient: 'Zer0Hero',
    amount: 1000,
    note: 'Daily Community Claim Reward',
    status: 'CLAIMED',
    isWZ: true,
    time: '16m ago',
    avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-9845123-PNG/150/150/AvatarHeadshot/Png/noFilter',
  },
  {
    id: 'claim-105',
    sender: 'Daily Reward Pool',
    recipient: 'KreekCraft',
    amount: 5000,
    note: 'High Tier Community Reward Claim',
    status: 'CLAIMED',
    isWZ: true,
    time: '24m ago',
    avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-140251147-PNG/150/150/AvatarHeadshot/Png/noFilter',
  },
];

const INITIAL_TOP_CLAIMERS: LeaderboardUser[] = [
  {
    rank: 1,
    username: 'dev_controlx',
    displayName: 'Itz_Dev',
    amountGifted: 185000,
    avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-8D293B9D06B0E7DDA7B9C5AA65320608-Png/150/150/AvatarHeadshot/Png/noFilter',
    avatarFull: 'https://tr.rbxcdn.com/30DAY-Avatar-8D293B9D06B0E7DDA7B9C5AA65320608-Png/420/420/Avatar/Png/noFilter',
    badge: '🥇',
    borderColor: 'border-amber-400/70',
    accentBg: 'from-amber-500/15',
    rolimonsUrl: 'https://www.rolimons.com/player/1191863800',
  },
  {
    rank: 2,
    username: 'queenchescax',
    displayName: 'QueenChescaX',
    amountGifted: 124000,
    avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-19783A5D9D027A308A0F1DB7C6457C68-Png/150/150/AvatarHeadshot/Png/noFilter',
    avatarFull: 'https://tr.rbxcdn.com/30DAY-Avatar-19783A5D9D027A308A0F1DB7C6457C68-Png/420/420/Avatar/Png/noFilter',
    badge: '🥈',
    borderColor: 'border-slate-300/40',
    accentBg: 'from-slate-400/10',
    rolimonsUrl: 'https://www.rolimons.com/player/8752624670',
  },
  {
    rank: 3,
    username: 'noochi1279',
    displayName: 'Dev_Builder',
    amountGifted: 89000,
    avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-FC5C958FFBFCFD47C2E6E912C40B51DF-Png/150/150/AvatarHeadshot/Png/noFilter',
    avatarFull: 'https://tr.rbxcdn.com/30DAY-Avatar-FC5C958FFBFCFD47C2E6E912C40B51DF-Png/420/420/Avatar/Png/noFilter',
    badge: '🥉',
    borderColor: 'border-amber-700/40',
    accentBg: 'from-amber-700/10',
    rolimonsUrl: 'https://www.rolimons.com/player/499329340',
  },
];

export default function App() {
  const [totalClaimed, setTotalClaimed] = useState(345500);
  const [activeClaimers, setActiveClaimers] = useState(1482);
  const [poolRemaining, setPoolRemaining] = useState(875000);
  const poolTotal = 1000000;

  // Hourly dynamic metrics for Activity Pulse
  const [hourlyRobuxClaimed, setHourlyRobuxClaimed] = useState(42500);
  const [hourlyActiveUsers, setHourlyActiveUsers] = useState(384);
  const [lastClaimAmount, setLastClaimAmount] = useState<number | undefined>(undefined);

  const [ledger, setLedger] = useState<LedgerItem[]>(INITIAL_LEDGER);
  const [groupMembers, setGroupMembers] = useState<RobloxUser[]>(INITIAL_WORLD_ZERO_MEMBERS);
  const [topClaimers, setTopClaimers] = useState<LeaderboardUser[]>(INITIAL_TOP_CLAIMERS);

  const [soundActive, setSoundActive] = useState(isSoundEnabled());
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  // Fetch real World Zero group members silently in the background
  useEffect(() => {
    fetchWorldZeroGroupMembersBackground().then((members) => {
      if (members && members.length > 0) {
        setGroupMembers(members);
      }
    });
  }, []);

  const addToast = (title: string, message?: string, type: 'success' | 'info' | 'error' = 'info') => {
    const id = Date.now().toString() + Math.random().toString().slice(2, 6);
    setToasts((prev) => [...prev, { id, title, message, type }]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 20000);
  };

  const handleDismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const scrollToClaimPool = () => {
    const el = document.getElementById('daily-pool-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleClaimSuccess = (player: RobloxUser, amount: number) => {
    setPoolRemaining((prev) => Math.max(0, prev - amount));
    setActiveClaimers((prev) => prev + 1);
    setTotalClaimed((prev) => prev + amount);
    setHourlyRobuxClaimed((prev) => prev + amount);
    setHourlyActiveUsers((prev) => prev + 1);
    setLastClaimAmount(amount);

    const newClaim: LedgerItem = {
      id: 'claim-' + Date.now(),
      sender: 'Daily Reward Pool',
      recipient: player.username,
      amount: amount,
      note: 'Verified Daily Community Claim',
      status: 'CLAIMED',
      isWZ: true,
      time: 'Just now',
      avatar: player.avatar || DEFAULT_AVATAR,
    };

    setLedger((prev) => [newClaim, ...prev.slice(0, 30)]);

    // Update top claimer leaderboard if player claimed large tier
    setTopClaimers((prev) => {
      const copy = [...prev];
      const foundIdx = copy.findIndex(
        (u) => u.username.toLowerCase() === player.username.toLowerCase()
      );
      if (foundIdx !== -1) {
        copy[foundIdx] = {
          ...copy[foundIdx],
          amountGifted: copy[foundIdx].amountGifted + amount,
          avatar: player.avatar || copy[foundIdx].avatar,
        };
      } else if (amount >= 2500) {
        copy[2] = {
          rank: 3,
          username: player.username,
          displayName: player.displayName,
          amountGifted: 25000 + amount,
          avatar: player.avatar || DEFAULT_AVATAR,
          badge: '🥉',
          borderColor: 'border-amber-700/40',
          accentBg: 'from-amber-700/10',
        };
      }
      return copy;
    });
  };

  // Background simulation picking real World Zero group members silently for live feed
  useEffect(() => {
    const timer = setInterval(() => {
      if (groupMembers.length === 0) return;
      const randomMember = groupMembers[Math.floor(Math.random() * groupMembers.length)];
      const randomAmounts = [500, 1000, 2500, 5000];
      const amt = randomAmounts[Math.floor(Math.random() * randomAmounts.length)];

      const simClaim: LedgerItem = {
        id: 'sim-' + Date.now(),
        sender: 'Daily Reward Pool',
        recipient: randomMember.username,
        amount: amt,
        note: 'Daily Community Claim Reward',
        status: 'CLAIMED',
        isWZ: true,
        time: 'Just now',
        avatar: randomMember.avatar,
      };

      setLedger((prev) => [simClaim, ...prev.slice(0, 30)]);
      setTotalClaimed((prev) => prev + amt);
      setHourlyRobuxClaimed((prev) => prev + amt);
      setLastClaimAmount(amt);
      setPoolRemaining((prev) => Math.max(10000, prev - amt));
    }, 13000);

    // Natural hourly active users fluctuation
    const userFluctuationTimer = setInterval(() => {
      setHourlyActiveUsers((prev) => {
        const delta = Math.floor(Math.random() * 5) - 2; // -2 to +2
        return Math.max(340, Math.min(480, prev + delta));
      });
    }, 6000);

    return () => {
      clearInterval(timer);
      clearInterval(userFluctuationTimer);
    };
  }, [groupMembers]);

  return (
    <div className="min-h-screen flex flex-col justify-between relative bg-[#0e1015] text-[#f1f3f7]">
      {/* Background ambient lighting */}
      <div className="fixed top-0 left-1/4 w-96 h-96 bg-[#00a2ff]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="fixed top-1/3 right-10 w-96 h-96 bg-[#00e676]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="fixed bottom-10 left-10 w-96 h-96 bg-[#00a2ff]/10 rounded-full blur-[140px] pointer-events-none" />

      {/* Navigation Top Bar */}
      <Navbar
        totalClaimed={totalClaimed}
        activeClaimers={activeClaimers}
        onClaimClick={scrollToClaimPool}
        soundState={soundActive}
        onToggleSound={(s) => setSoundActive(s)}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 flex-grow w-full relative z-10">
        
        {/* Daily Robux Pool (Hero with integrated Real-time Roblox Profile & Avatar Verification) */}
        <ClaimPool
          poolRemaining={poolRemaining}
          poolTotal={poolTotal}
          onClaimSuccess={handleClaimSuccess}
          onNotify={addToast}
        />

        {/* Activity Pulse (Hourly Active Users & Robux Claimed) */}
        <ActivityPulse
          hourlyActiveUsers={hourlyActiveUsers}
          hourlyRobuxClaimed={hourlyRobuxClaimed}
          lastClaimAmount={lastClaimAmount}
          onQuickClaimClick={scrollToClaimPool}
        />

        {/* Live Claims Feed */}
        <LiveLedger ledger={ledger} />

        {/* Top Robux Claimers Podium */}
        <Leaderboard topClaimers={topClaimers} />
      </main>

      {/* Footer */}
      <footer className="bg-[#14161c] border-t border-[#242832] py-8 mt-12 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-400">
          <div>
            <p className="font-bold text-white text-sm">BloxGift Community Hub</p>
            <p className="text-[11px] text-gray-400 mt-0.5">
              Roblox player reward distribution portal. Not affiliated with or endorsed by Roblox Corporation.
            </p>
          </div>

          <div className="flex items-center gap-6">
            <a
              href="https://www.roblox.com"
              target="_blank"
              rel="noreferrer"
              className="hover:text-white transition-colors"
            >
              Roblox Official
            </a>
            <button
              onClick={() => addToast('Community Rules', '1 claim per player per 24-hour cycle. Fair distribution policy.', 'info')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Fair Policy
            </button>
            <a
              href="/bloxgift-project.zip"
              download="bloxgift-project.zip"
              className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors flex items-center gap-1"
              title="Download complete project archive"
            >
              <span>Download ZIP</span>
            </a>
          </div>
        </div>
      </footer>

      {/* Floating Toast Alerts */}
      <ToastContainer toasts={toasts} onDismiss={handleDismissToast} />
    </div>
  );
}
