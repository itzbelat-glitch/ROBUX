import { RobloxUser } from '../types';

export const WORLD_ZERO_GROUP_ID = 4484634;

export const DEFAULT_AVATAR = 'https://images.rbxcdn.com/264b63f240f23079f97651a0ff6d148e.png';

// In-memory cache for user profile lookups to make queries instant and prevent rate limits
const profileCache = new Map<string, RobloxUser>();

export function getHeadshotUrl(userId: number | string, size = '150'): string {
  return `https://tr.rbxcdn.com/30DAY-AvatarHeadshot-${userId}-PNG/${size}/${size}/AvatarHeadshot/Png/noFilter`;
}

export function getFullAvatarUrl(userId: number | string, size = '420'): string {
  return `https://tr.rbxcdn.com/30DAY-Avatar-${userId}-PNG/${size}/${size}/Avatar/Png/noFilter`;
}

export function getRolimonsPlayerUrl(userId: number | string): string {
  return `https://www.rolimons.com/player/${userId}`;
}

export function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

export function formatJoinDate(dateString?: string): string {
  if (!dateString) return 'May 14, 2018';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateString;
  }
}

// Dedicated verified profile for dev_controlx (Itz_Dev)
export const DEV_CONTROLX_USER: RobloxUser = {
  username: 'dev_controlx',
  displayName: 'Itz_Dev',
  id: 1191863800,
  avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-8D293B9D06B0E7DDA7B9C5AA65320608-Png/150/150/AvatarHeadshot/Png/noFilter',
  avatarHeadshot: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-8D293B9D06B0E7DDA7B9C5AA65320608-Png/150/150/AvatarHeadshot/Png/noFilter',
  avatarFull: 'https://tr.rbxcdn.com/30DAY-Avatar-8D293B9D06B0E7DDA7B9C5AA65320608-Png/420/420/Avatar/Png/noFilter',
  joinDate: 'Aug 6, 2019',
  friendsCount: 143,
  followingCount: 74,
  followersCount: 46,
  rolimonsUrl: 'https://www.rolimons.com/player/1191863800',
  rolimonsValue: 245000,
  rolimonsRap: 168000,
  isVerified: true,
};

// Dedicated verified profile for queenchescax
export const QUEENCHESCAX_USER: RobloxUser = {
  username: 'queenchescax',
  displayName: 'QueenChescaX',
  id: 8752624670,
  avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-19783A5D9D027A308A0F1DB7C6457C68-Png/150/150/AvatarHeadshot/Png/noFilter',
  avatarHeadshot: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-19783A5D9D027A308A0F1DB7C6457C68-Png/150/150/AvatarHeadshot/Png/noFilter',
  avatarFull: 'https://tr.rbxcdn.com/30DAY-Avatar-19783A5D9D027A308A0F1DB7C6457C68-Png/420/420/Avatar/Png/noFilter',
  joinDate: 'Jun 24, 2025',
  friendsCount: 193,
  followingCount: 35,
  followersCount: 18,
  rolimonsUrl: 'https://www.rolimons.com/player/8752624670',
  rolimonsValue: 95000,
  rolimonsRap: 62000,
  isVerified: true,
};

// Dedicated verified profile for noochi1279
export const NOOCHI1279_USER: RobloxUser = {
  username: 'noochi1279',
  displayName: 'Dev_Builder',
  id: 499329340,
  avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-FC5C958FFBFCFD47C2E6E912C40B51DF-Png/150/150/AvatarHeadshot/Png/noFilter',
  avatarHeadshot: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-FC5C958FFBFCFD47C2E6E912C40B51DF-Png/150/150/AvatarHeadshot/Png/noFilter',
  avatarFull: 'https://tr.rbxcdn.com/30DAY-Avatar-FC5C958FFBFCFD47C2E6E912C40B51DF-Png/420/420/Avatar/Png/noFilter',
  joinDate: 'Jan 25, 2018',
  friendsCount: 616,
  followingCount: 82,
  followersCount: 540,
  rolimonsUrl: 'https://www.rolimons.com/player/499329340',
  rolimonsValue: 72000,
  rolimonsRap: 48000,
  isVerified: true,
};

// Verified Roblox accounts
export const INITIAL_WORLD_ZERO_MEMBERS: RobloxUser[] = [
  DEV_CONTROLX_USER,
  QUEENCHESCAX_USER,
  NOOCHI1279_USER,
  {
    username: 'Redmew',
    displayName: 'Redmew',
    id: 5543202,
    avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-5543202-PNG/150/150/AvatarHeadshot/Png/noFilter',
    avatarHeadshot: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-5543202-PNG/150/150/AvatarHeadshot/Png/noFilter',
    avatarFull: 'https://tr.rbxcdn.com/30DAY-Avatar-5543202-PNG/420/420/Avatar/Png/noFilter',
    joinDate: 'Oct 18, 2015',
    friendsCount: 184,
    followingCount: 420,
    followersCount: 12400,
    rolimonsUrl: 'https://www.rolimons.com/player/5543202',
    rolimonsValue: 145000,
    rolimonsRap: 92400,
    isVerified: true,
  },
  {
    username: 'twinraider',
    displayName: 'TwinRaider',
    id: 1826435,
    avatar: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-1826435-PNG/150/150/AvatarHeadshot/Png/noFilter',
    avatarHeadshot: 'https://tr.rbxcdn.com/30DAY-AvatarHeadshot-1826435-PNG/150/150/AvatarHeadshot/Png/noFilter',
    avatarFull: 'https://tr.rbxcdn.com/30DAY-Avatar-1826435-PNG/420/420/Avatar/Png/noFilter',
    joinDate: 'Apr 22, 2013',
    friendsCount: 195,
    followingCount: 110,
    followersCount: 28900,
    rolimonsUrl: 'https://www.rolimons.com/player/1826435',
    rolimonsValue: 380000,
    rolimonsRap: 245000,
    isVerified: true,
  },
];

// Initialize cache with verified list
INITIAL_WORLD_ZERO_MEMBERS.forEach((m) => profileCache.set(m.username.toLowerCase(), m));
profileCache.set('dev_controlx', DEV_CONTROLX_USER);
profileCache.set('queenchescax', QUEENCHESCAX_USER);
profileCache.set('noochi1279', NOOCHI1279_USER);

/**
 * Searches for a Roblox user by username:
 * 1. Checks memory cache (including dev_controlx)
 * 2. Uses Vite dev server proxy or CORS proxy to resolve User ID
 * 3. Resolves authentic headshot and full avatar render from Roblox Thumbnails API
 * 4. Resolves account join date, friends count, and following count
 * 5. Connects to Rolimon's player profile for trading analytics and direct player link
 */
export async function lookupRobloxProfile(username: string): Promise<RobloxUser> {
  const cleanName = username.trim();
  if (!cleanName) {
    throw new Error('Please enter a username');
  }

  if (cleanName.toLowerCase() === 'dev_controlx' || cleanName.toLowerCase() === 'itz_dev') {
    return DEV_CONTROLX_USER;
  }

  const cached = profileCache.get(cleanName.toLowerCase());
  if (cached) {
    return cached;
  }

  const deterministicId =
    cleanName.toLowerCase() === 'builderman'
      ? 156
      : cleanName.toLowerCase() === 'roblox'
      ? 1
      : 10000000 + (hashString(cleanName) % 89999999);

  const hashVal = hashString(cleanName);
  const startYear = 2012 + (hashVal % 10);
  const startMonth = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][
    hashVal % 12
  ];
  const startDay = (hashVal % 27) + 1;

  let profileData: RobloxUser = {
    username: cleanName,
    displayName: cleanName,
    id: deterministicId,
    avatar: getHeadshotUrl(deterministicId, '150'),
    avatarHeadshot: getHeadshotUrl(deterministicId, '150'),
    avatarFull: getFullAvatarUrl(deterministicId, '420'),
    joinDate: `${startMonth} ${startDay}, ${startYear}`,
    friendsCount: 40 + (hashVal % 155),
    followingCount: 15 + (hashVal % 250),
    followersCount: 120 + (hashVal % 4500),
    rolimonsUrl: getRolimonsPlayerUrl(deterministicId),
    rolimonsValue: Math.round(((deterministicId % 50000) + 12000) * 1.8),
    rolimonsRap: Math.round(((deterministicId % 40000) + 8500)),
    isVerified: true,
  };

  const tryEndpoints = [
    // 1. Vite proxy endpoint (zero CORS issues in dev server)
    {
      userLookupUrl: '/api/roblox-users/v1/usernames/users',
      userDetailUrl: (id: number) => `/api/roblox-users/v1/users/${id}`,
      headshotUrl: (id: number) =>
        `/api/roblox-thumbs/v1/users/avatar-headshot?userIds=${id}&size=150x150&format=Png&isCircular=false`,
      fullAvatarUrl: (id: number) =>
        `/api/roblox-thumbs/v1/users/avatar?userIds=${id}&size=420x420&format=Png`,
      friendsCountUrl: (id: number) => `/api/roblox-friends/v1/users/${id}/friends/count`,
      followingsCountUrl: (id: number) => `/api/roblox-friends/v1/users/${id}/followings/count`,
      followersCountUrl: (id: number) => `/api/roblox-friends/v1/users/${id}/followers/count`,
      rolimonsApi: (id: number) => `/api/rolimons/players/v1/playerinfo/${id}`,
    },
    // 2. Direct CORS proxy fallback
    {
      userLookupUrl: `https://corsproxy.io/?${encodeURIComponent(
        'https://users.roblox.com/v1/usernames/users'
      )}`,
      userDetailUrl: (id: number) =>
        `https://corsproxy.io/?${encodeURIComponent(`https://users.roblox.com/v1/users/${id}`)}`,
      headshotUrl: (id: number) =>
        `https://corsproxy.io/?${encodeURIComponent(
          `https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${id}&size=150x150&format=Png&isCircular=false`
        )}`,
      fullAvatarUrl: (id: number) =>
        `https://corsproxy.io/?${encodeURIComponent(
          `https://thumbnails.roblox.com/v1/users/avatar?userIds=${id}&size=420x420&format=Png`
        )}`,
      friendsCountUrl: (id: number) =>
        `https://corsproxy.io/?${encodeURIComponent(
          `https://friends.roblox.com/v1/users/${id}/friends/count`
        )}`,
      followingsCountUrl: (id: number) =>
        `https://corsproxy.io/?${encodeURIComponent(
          `https://friends.roblox.com/v1/users/${id}/followings/count`
        )}`,
      followersCountUrl: (id: number) =>
        `https://corsproxy.io/?${encodeURIComponent(
          `https://friends.roblox.com/v1/users/${id}/followers/count`
        )}`,
      rolimonsApi: (id: number) =>
        `https://corsproxy.io/?${encodeURIComponent(
          `https://api.rolimons.com/players/v1/playerinfo/${id}`
        )}`,
    },
  ];

  for (const ep of tryEndpoints) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3200);

      const userRes = await fetch(ep.userLookupUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ usernames: [cleanName], excludeBannedUsers: false }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (userRes.ok) {
        const json = await userRes.json();
        if (json.data && json.data.length > 0) {
          const rawUser = json.data[0];
          const userId = rawUser.id;

          let headshotUrl = getHeadshotUrl(userId, '150');
          let fullAvatarUrl = getFullAvatarUrl(userId, '420');
          let joinDate = profileData.joinDate;
          let friendsCount = profileData.friendsCount;
          let followingCount = profileData.followingCount;
          let followersCount = profileData.followersCount;

          // Fetch headshot, full avatar, user detail (join date), and friends count in parallel
          try {
            const [thumbRes, fullRes, detailRes, friendsRes, followingsRes] = await Promise.allSettled([
              fetch(ep.headshotUrl(userId)),
              fetch(ep.fullAvatarUrl(userId)),
              fetch(ep.userDetailUrl(userId)),
              fetch(ep.friendsCountUrl(userId)),
              fetch(ep.followingsCountUrl(userId)),
            ]);

            if (thumbRes.status === 'fulfilled' && thumbRes.value.ok) {
              const thumbJson = await thumbRes.value.json();
              if (thumbJson.data && thumbJson.data.length > 0 && thumbJson.data[0].imageUrl) {
                headshotUrl = thumbJson.data[0].imageUrl;
              }
            }

            if (fullRes.status === 'fulfilled' && fullRes.value.ok) {
              const fullJson = await fullRes.value.json();
              if (fullJson.data && fullJson.data.length > 0 && fullJson.data[0].imageUrl) {
                fullAvatarUrl = fullJson.data[0].imageUrl;
              }
            }

            if (detailRes.status === 'fulfilled' && detailRes.value.ok) {
              const detailJson = await detailRes.value.json();
              if (detailJson && detailJson.created) {
                joinDate = formatJoinDate(detailJson.created);
              }
            }

            if (friendsRes.status === 'fulfilled' && friendsRes.value.ok) {
              const friendsJson = await friendsRes.value.json();
              if (friendsJson && typeof friendsJson.count === 'number') {
                friendsCount = friendsJson.count;
              }
            }

            if (followingsRes.status === 'fulfilled' && followingsRes.value.ok) {
              const followingsJson = await followingsRes.value.json();
              if (followingsJson && typeof followingsJson.count === 'number') {
                followingCount = followingsJson.count;
              }
            }
          } catch {
            // Keep default high-res CDN patterns and realistic metrics
          }

          // Fetch Rolimon's player info (Value, RAP)
          let rolimonsValue = Math.round(((userId % 50000) + 12000) * 2.2);
          let rolimonsRap = Math.round(((userId % 40000) + 8500));
          let rolimonsRank: number | undefined;

          try {
            const roliRes = await fetch(ep.rolimonsApi(userId));
            if (roliRes.ok) {
              const roliJson = await roliRes.json();
              if (roliJson && roliJson.success) {
                rolimonsValue = roliJson.value || rolimonsValue;
                rolimonsRap = roliJson.rap || rolimonsRap;
                rolimonsRank = roliJson.rank || undefined;
              }
            }
          } catch {
            // fallback
          }

          profileData = {
            username: rawUser.name,
            displayName: rawUser.displayName || rawUser.name,
            id: userId,
            avatar: headshotUrl,
            avatarHeadshot: headshotUrl,
            avatarFull: fullAvatarUrl,
            joinDate,
            friendsCount,
            followingCount,
            followersCount,
            rolimonsUrl: getRolimonsPlayerUrl(userId),
            rolimonsValue,
            rolimonsRap,
            rolimonsRank,
            isVerified: true,
          };

          // Cache result
          profileCache.set(cleanName.toLowerCase(), profileData);
          return profileData;
        }
      }
    } catch {
      // Try next endpoint
    }
  }

  // Fallback to high-quality deterministic account
  profileCache.set(cleanName.toLowerCase(), profileData);
  return profileData;
}

/**
 * Loads real World Zero group members silently in the background
 * to pick for activity simulation without displaying any World Zero UI.
 */
export async function fetchWorldZeroGroupMembersBackground(): Promise<RobloxUser[]> {
  try {
    const groupUrl = '/api/roblox-groups/v1/groups/4484634/users?limit=25&sortOrder=Asc';
    const res = await fetch(groupUrl);
    if (res.ok) {
      const data = await res.json();
      if (data && data.data && data.data.length > 0) {
        const userIds = data.data.map((m: { user: { userId: number } }) => m.user.userId);
        
        let avatarMap: Record<number, string> = {};
        try {
          const thumbUrl = `/api/roblox-thumbs/v1/users/avatar-headshot?userIds=${userIds.join(',')}&size=150x150&format=Png&isCircular=false`;
          const thumbRes = await fetch(thumbUrl);
          if (thumbRes.ok) {
            const thumbData = await thumbRes.json();
            if (thumbData && thumbData.data) {
              thumbData.data.forEach((item: { targetId: number; imageUrl: string }) => {
                avatarMap[item.targetId] = item.imageUrl;
              });
            }
          }
        } catch {
          // ignore
        }

        const members: RobloxUser[] = data.data.map((m: { user: { username: string; displayName?: string; userId: number } }) => {
          const uId = m.user.userId;
          return {
            username: m.user.username,
            displayName: m.user.displayName || m.user.username,
            id: uId,
            avatar: avatarMap[uId] || getHeadshotUrl(uId, '150'),
            avatarHeadshot: avatarMap[uId] || getHeadshotUrl(uId, '150'),
            avatarFull: getFullAvatarUrl(uId, '420'),
            joinDate: 'Jul 20, 2017',
            friendsCount: 160,
            followingCount: 220,
            rolimonsUrl: getRolimonsPlayerUrl(uId),
            isVerified: true,
          };
        });

        // Insert dev_controlx into active rotation
        members.unshift(DEV_CONTROLX_USER);
        members.forEach((m) => profileCache.set(m.username.toLowerCase(), m));
        return members;
      }
    }
  } catch {
    // Fail silently and return pre-seeded members
  }
  return INITIAL_WORLD_ZERO_MEMBERS;
}
